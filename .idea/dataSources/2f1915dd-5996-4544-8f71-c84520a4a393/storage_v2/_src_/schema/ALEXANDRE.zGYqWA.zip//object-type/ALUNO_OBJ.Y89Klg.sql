create type Aluno_obj FORCE AS object(
    nome varchar(80),
    idade number
    );


/

