create PACKAGE PKG_ALUNO
IS
    --AQUI PODE DECLARAR VARIÁVEIS, PROCEDURE, FUNCTION (TUDO COMO PÚBLICA)
    r_NOME varchar(40);
    procedure delete_aluno(pCodAluno number);
    procedure add_aluno(pAluno aluno_obj);
end;
/

