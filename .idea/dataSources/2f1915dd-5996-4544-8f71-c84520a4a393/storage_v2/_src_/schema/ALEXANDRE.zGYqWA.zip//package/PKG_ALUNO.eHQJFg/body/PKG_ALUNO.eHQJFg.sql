create package body PKG_ALUNO --corpo
  is
    procedure add_aluno(pAluno aluno_obj)
        is
            begin
                insert into tab_aluno(id_aluno, nome, idade) values(seq_aluno_estudo.nextval, pAluno.nome, pAluno.idade);
            end;
    procedure search_aluno(pCodAluno number)
        is
            begin
            r_NOME := '';
                select NOME
                INTO r_NOME
                FROM TAB_ALUNO
                WHERE id_aluno = pCodAluno;

            exception
                WHEN NO_DATA_FOUND THEN
                    dbms_output.put_line('Aluno não encontrado');

            end;
    procedure delete_aluno(pCodAluno number)
        is
            begin
                search_aluno(pCodAluno);
                if length(r_NOME) > 0 then
                    delete from tab_aluno where id_aluno = pCodAluno;
                end if;
            end;
end;
/

