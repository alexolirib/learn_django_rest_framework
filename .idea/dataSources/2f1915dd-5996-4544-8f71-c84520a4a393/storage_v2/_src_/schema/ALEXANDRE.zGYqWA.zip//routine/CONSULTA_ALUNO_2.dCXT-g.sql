create procedure consulta_aluno_2(
    --pega toda a estrutura de tipo da tabela
    pRegistro in out tab_aluno%rowtype
)
is
    cursor csql is 
        select * from tab_aluno where id_aluno = pRegistro.id_aluno;
begin
 open csql;
 --jogando o registro para variável para retorna 
 fetch csql into pRegistro;
 close csql;    
end;
/

