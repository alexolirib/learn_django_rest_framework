create procedure consulte_aluno --in = variavel de entrada e out = variavel de saída
(
    pCodigo in taluno.cod_aluno%type,
    pNome out taluno.nome%type
)
is 
begin
    select nome 
    into pNome
    from tab_aluno
    where id_aluno = pCodigo;
end;

/

