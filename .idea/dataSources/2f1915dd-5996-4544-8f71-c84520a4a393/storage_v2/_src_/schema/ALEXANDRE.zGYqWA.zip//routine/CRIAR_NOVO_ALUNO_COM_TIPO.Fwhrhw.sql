create procedure criar_novo_aluno_com_tipo(nome_a varchar, idade_a number) is

begin
    insert into tab_aluno(id_aluno, nome, idade) values(seq_aluno_estudo.nextval, nome_a, idade_a);

end;
/

