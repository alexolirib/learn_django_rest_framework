create procedure criar_novo_aluno_type_object(pAluno in aluno_obj) is
begin
    insert into tab_aluno(id_aluno, nome, idade) values(seq_aluno_estudo.nextval, pAluno.nome, pAluno.idade);
end;
/

