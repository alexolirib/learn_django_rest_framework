create PROCEDURE FORMAT_TELEFONE(num_tel IN OUT VARCHAR) IS
BEGIN
    num_tel := SUBSTR(num_tel, 1, 4) || '-' || substr(num_tel, 5, 4);

END;

/

