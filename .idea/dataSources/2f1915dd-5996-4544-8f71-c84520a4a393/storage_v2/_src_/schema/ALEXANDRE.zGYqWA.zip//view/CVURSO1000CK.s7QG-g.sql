create view CVURSO1000CK as
SELECT cod_curso, nome, valor
      FROM tcurso 
      WHERE valor = 1000
    WITH CHECK OPTION
/

