create view V_CONTRATO as
SELECT Trunc(DATA) AS DATA,
         Max(DESCONTO) AS MAXIMO,
         Avg(DESCONTO) AS MEDIA,
         Count(*) QTD
  FROM TCONTRATO
  GROUP BY(Trunc(DATA))
/

